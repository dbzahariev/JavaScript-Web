import React, {Component} from 'react'

export default class Home extends Component {
    render = () => {
        return (
            <div className="welcomeHome">
                <h1>This is our shop</h1>
            </div>
        )
    }
}