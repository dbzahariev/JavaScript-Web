import React, { Component } from "react";

export default class Login extends Component {
    render() {
        return (
            <div className='map'>
                <iframe title='google maps' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2932.65121663663!2d23.356954815187834!3d42.689929979166166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa8593b102143d%3A0x48003b7a98e47cbc!2z0YPQuy4g4oCe0JPQtdC-0YDQs9C4INCc0LjQvdGH0LXQsuKAnCAyLTEwLCAxNTA1INCg0LXQtNGD0YLQsCwg0KHQvtGE0LjRjw!5e0!3m2!1sbg!2sbg!4v1531595727520" width="400" height="300" frameBorder="0" allowFullScreen></iframe>
            </div>
        )
    }
}